insert into empleado (id, nombre, apellidos, email) values (NEXTVAL('hibernate_sequence'),'Luis Miguel','López','luismi.lopez@triana.com');
insert into empleado (id, nombre, apellidos, email) values (NEXTVAL('hibernate_sequence'),'Ángel','Naranjo','angel.narajo@triana.com');

insert into producto(id,nombre, precio, descripcion, descuento, color) values  (NEXTVAL('hibernate_sequence'),'Champoo',10,'champo para no calvos',0,'rojo');