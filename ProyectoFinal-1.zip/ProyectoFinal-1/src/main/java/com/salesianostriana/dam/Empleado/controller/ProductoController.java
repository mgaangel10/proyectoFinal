package com.salesianostriana.dam.Empleado.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.salesianostriana.dam.Empelado.model.Producto;
import com.salesianostriana.dam.Empleado.service.ProductoService;

@Controller

public class ProductoController {
	
	private ProductoService prod;
	
	@GetMapping("/addProd")
	public String mostrarFormulario(Model model) {
		model.addAttribute("producto",new Producto());
		return "addProductos";
	}
	
	@PostMapping("/nuevoProducto")
	public String procesarFormulario(@ModelAttribute("producto") Producto p) {
		prod.add(p);
		return "redirect:/listaProductos";
	}
	@GetMapping("/editarP/{id}")
	public String mostrarFormularioEdicion(@PathVariable("id") long id, Model model) {
		Producto aEditar = prod.findById(id);
				if (aEditar != null) {
			model.addAttribute("producto", aEditar);
			return "addProducto";
		} else {
			return "redirect:/listaProductos";
		}
	}
	
	@GetMapping("/listaProductos")
	public String MostrarProducto(Model model) {
		model.addAttribute("lista",prod.findAll());
		return "listaprod";	
	}
	
	@GetMapping("/borrarP/{id}")
	public String borrar(@PathVariable("id") long id) {
		prod.delete(id);
		return "redirect:/listaProductos";
	}
	
	
	
	
}

