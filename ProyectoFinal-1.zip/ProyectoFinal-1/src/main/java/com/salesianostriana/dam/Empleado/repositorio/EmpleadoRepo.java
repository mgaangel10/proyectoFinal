package com.salesianostriana.dam.Empleado.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.salesianostriana.dam.Empelado.model.Empleado;

public interface EmpleadoRepo extends JpaRepository<Empleado, Long>{

}
