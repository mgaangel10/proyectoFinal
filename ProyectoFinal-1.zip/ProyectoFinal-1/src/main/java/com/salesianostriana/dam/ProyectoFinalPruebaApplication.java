package com.salesianostriana.dam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoFinalPruebaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoFinalPruebaApplication.class, args);
	}

}
