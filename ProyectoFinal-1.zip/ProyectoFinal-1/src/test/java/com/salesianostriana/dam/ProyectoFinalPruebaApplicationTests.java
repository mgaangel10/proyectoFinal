package com.salesianostriana.dam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoFinalPruebaApplicationTests {

	@Test
	void contextLoads() {
	}

}
